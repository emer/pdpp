// instantiate virtual tables..

#include "pdp++bench.h"
