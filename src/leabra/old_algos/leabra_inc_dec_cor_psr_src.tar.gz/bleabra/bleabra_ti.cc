// -*- C++ -*-
// template instantiation file
 
// please include relevant files and instantiate templates here.. 

#include "biobel.h"

template class taList<LayerLink>;
template class SpecPtr<BioBelLayerSpec>;
template class taPtrList<BioBelUnit>;
