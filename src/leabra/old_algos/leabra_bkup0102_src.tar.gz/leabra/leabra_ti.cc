// -*- C++ -*-
// template instantiation file
 
// please include relevant files and instantiate templates here.. 

#include "leabra.h"

template class taList<LayerLink>;
template class SpecPtr<LeabraLayerSpec>;
template class taPtrList<LeabraUnit>;
