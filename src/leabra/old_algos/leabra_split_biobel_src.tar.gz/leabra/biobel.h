/* -*- C++ -*- */
/*=============================================================================
//									      //
// This file is part of the PDP++ software package.			      //
//									      //
// Copyright (C) 1995 Randall C. O'Reilly, Chadley K. Dawson, 		      //
//		      James L. McClelland, and Carnegie Mellon University     //
//     									      //
// Permission to use, copy, and modify this software and its documentation    //
// for any purpose other than distribution-for-profit is hereby granted	      //
// without fee, provided that the above copyright notice and this permission  //
// notice appear in all copies of the software and related documentation.     //
//									      //
// Permission to distribute the software or modified or extended versions     //
// thereof on a not-for-profit basis is explicitly granted, under the above   //
// conditions. 	HOWEVER, THE RIGHT TO DISTRIBUTE THE SOFTWARE OR MODIFIED OR  //
// EXTENDED VERSIONS THEREOF FOR PROFIT IS *NOT* GRANTED EXCEPT BY PRIOR      //
// ARRANGEMENT AND WRITTEN CONSENT OF THE COPYRIGHT HOLDERS.                  //
// 									      //
// Note that the taString class, which is derived from the GNU String class,  //
// is Copyright (C) 1988 Free Software Foundation, written by Doug Lea, and   //
// is covered by the GNU General Public License, see ta_string.h.             //
// The iv_graphic library and some iv_misc classes were derived from the      //
// InterViews morpher example and other InterViews code, which is             //
// Copyright (C) 1987, 1988, 1989, 1990, 1991 Stanford University             //
// Copyright (C) 1991 Silicon Graphics, Inc.				      //
//									      //
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,         //
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 	      //
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  	      //
// 									      //
// IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY BE LIABLE FOR ANY SPECIAL,    //
// INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES  //
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT     //
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,      //
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS        //
// SOFTWARE. 								      //
==============================================================================*/

// biobel.h 

#ifndef biobel_h
#ifdef __GNUG__
#pragma interface
#endif
#define biobel_h

#include <pdp/netstru.h>
#include <pdp/sched_proc.h>
#include <ta_misc/fun_lookup.h>
#include <leabra/leabra_TA_type.h>
#include <math.h>
#include <values.h>

// pre-declare

class BioBelCon;
class BioBelConSpec;
class BioBelCon_Group;
class BioBelUnitSpec;
class BioBelUnit;
class BioBelUnit_Group;
class BioBelInhib;
class BioBelLayerSpec;
class BioBelLayer;
class BioBelMaxDa;

// _

// Relative Belief in biological terms (BioBel) 
// note that the weights are subject to scaling by wt_scale, but are stored
// in 0-1 normalized form

class BioBelCon : public Connection {
  // BioBel connection
public:
  float		wt_lin;		// #NO_VIEW linear (internal) weight value (on which learning occurs)

  void 	Initialize()		{ wt_lin = 0.0f; }
  void	Destroy()		{ };
  void	Copy_(const BioBelCon& cp) { wt_lin = cp.wt_lin; }
  COPY_FUNS(BioBelCon, Connection);
  TA_BASEFUNS(BioBelCon);
};

class WtScaleSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER weight scaling specification
public:
  float		abs;		// absolute scaling (not subject to normalization)
  float		rel;		// relative scaling (subject to normalization)

  float		NetScale() 	{ return abs * rel; }

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(WtScaleSpec);
  COPY_FUNS(WtScaleSpec, taBase);
  TA_BASEFUNS(WtScaleSpec);
};

class WtSigSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER sigmoidal weight function specification
public:
  float		gain;		// gain (contrast, sharpness) of the function
  float		off;		// offset of the function (1=centered at .5, >1=higher)

  // function for implementing weight sigmodid
  static float	SigFun(float w, float gain, float off) {
    float wrat;
    if(w == 0.0f) wrat = MAXFLOAT;
    else if(w == 1.0f) wrat = 0.0f;
    else wrat = off * (1.0f - w) / w;
    return 1.0f / (1.0f + powf(wrat, gain));
  }

  // function for implementing inverse of weight sigmoid
  static float	SigFunInv(float w, float gain, float off) {
    float wrat;
    if(w == 0.0f) wrat = MAXFLOAT;
    else if(w == 1.0f) wrat = 0.0f;
    else wrat = (1.0f - w) / w;
    return 1.0f / (1.0f + (1.0f / off) * powf(wrat, 1.0f / gain));
  }

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(WtSigSpec);
  COPY_FUNS(WtSigSpec, taBase);
  TA_BASEFUNS(WtSigSpec);
};

class FixedSAvg : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER provide fixed sending average activity level
public:
  bool		fix;		// override automatic computation of savg (and use fixed val)
  float		savg;		// fixed sending average activity value

  float 	GetSAvg(float slayer_pct)
  { float rval = slayer_pct; if(fix) rval = savg; return rval; }

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(FixedSAvg);
  COPY_FUNS(FixedSAvg, taBase);
  TA_BASEFUNS(FixedSAvg);
};

class BioBelConSpec : public ConSpec {
  // BioBel relative belief connection specs
public:
  WtScaleSpec	wt_scale;	// scale weight values, both relative and absolute factors
  WtSigSpec	wt_sig;		// sigmoidal weight function for contrast enhancement
  FixedSAvg	fix_savg;	// fixed sending average activity value (override automatic computation)
  bool		inhib;		// this makes the connection inhibitory (to g_i instead of net)
  FunLookup	wt_sig_fun;	// #HIDDEN #NO_SAVE #NO_INHERIT computes wt sigmoidal fun

  void		C_Compute_WtFmLin(BioBelCon_Group*, BioBelCon* cn)
  { cn->wt = wt_sig_fun.Eval(cn->wt_lin);  }
  inline virtual void	Compute_WtFmLin(BioBelCon_Group* gp);
  // compute actual weight value from linear weight value

  void		C_Compute_LinFmWt(BioBelCon_Group*, BioBelCon* cn)
  { cn->wt_lin = WtSigSpec::SigFunInv(cn->wt, wt_sig.gain, wt_sig.off); }
  inline virtual void	Compute_LinFmWt(BioBelCon_Group* gp);
  // compute linear weight value from actual weight value

  inline void	C_InitWtState_post(Con_Group* cg, Connection* cn, Unit* ru, Unit* su);

  inline float 	C_Compute_Net(BioBelCon* cn, Unit*, Unit* su);
  inline float 	Compute_Net(Con_Group* cg, Unit* ru);
  // receiver-based net input 

  inline void 	C_Send_Net(BioBelCon_Group* cg, BioBelCon* cn, Unit* ru, Unit* su);
  inline void 	Send_Net(Con_Group* cg, Unit* su);
  // sender-based net input computation

  inline void 	C_Send_Inhib(BioBelCon_Group* cg, BioBelCon* cn, BioBelUnit* ru, BioBelUnit* su);
  inline void 	Send_Inhib(BioBelCon_Group* cg, BioBelUnit* su);
  // sender-based inhibitiory net input computation

  void		ApplySymmetry(Con_Group* cg, Unit* ru);
  // redo for copying wt_lin!

  virtual void	CreateWtSigFun(); // create the wt_sig_fun

  void	UpdateAfterEdit();
  void 	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  SIMPLE_COPY(BioBelConSpec);
  COPY_FUNS(BioBelConSpec, ConSpec);
  TA_BASEFUNS(BioBelConSpec);
};

class BioBelCon_Group : public Con_Group {
  // BioBel relative belief connection group
public:
  float		scale_eff;	// #NO_SAVE effective scale parameter for netin

  void	Compute_LinFmWt()  { ((BioBelConSpec*)spec.spec)->Compute_LinFmWt(this); }

  void	Compute_WtFmLin()  { ((BioBelConSpec*)spec.spec)->Compute_WtFmLin(this); }

  void	Copy_Weights(const Con_Group* src)
  { Con_Group::Copy_Weights(src); Compute_LinFmWt(); }
  void	ReadWeights(istream& strm)
  { Con_Group::ReadWeights(strm); Compute_LinFmWt(); }
  void	TransformWeights(const SimpleMathSpec& trans)
  { Con_Group::TransformWeights(trans); Compute_LinFmWt(); }
  void	AddNoiseToWeights(const Random& noise_spec)
  { Con_Group::AddNoiseToWeights(noise_spec); Compute_LinFmWt(); }

  void 	Initialize();
  void	Destroy()		{ };
  void	Copy_(const BioBelCon_Group& cp);
  COPY_FUNS(BioBelCon_Group, Con_Group);
  TA_BASEFUNS(BioBelCon_Group);
};

class BioBelChannels : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER channels used in BioBel
public:
  float		e;		// excitatory
  float		l;		// leak
  float		i;		// inhibitory
  float		h;		// hysteresis (Ca)
  float		a;		// accomodation (k)

  void	Initialize();
  void	Destroy()	{ };
  void 	Copy_(const BioBelChannels& cp);
  COPY_FUNS(BioBelChannels, taBase);
  TA_BASEFUNS(BioBelChannels);
};

class VChanSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER voltage gated channel specs
public:
  bool		on;		// true if channel is on
  float		b_dt;		// time constant for integrating basis variable
  float		a_thr;		// activation threshold of the channel
  float		d_thr;		// deactivation threshold of the channel
  float		g_dt;		// time constant for incrementing conductance
  bool		init;		// initialize variables when state is intialized (else with weights)

  void	UpdateBasis(float& basis, bool& on_off, float& gc, float act) {
    if(on) {
      basis += b_dt * (act - basis);
      if(basis > a_thr)
	on_off = true;
      if(on_off && (basis < d_thr))
	on_off = false;
      gc += g_dt * ((float)on_off - gc);
    }
  }

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(VChanSpec);
  COPY_FUNS(VChanSpec, taBase);
  TA_BASEFUNS(VChanSpec);
};

class VChanBasis : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER basis variables for vchannels
public:
  float		hyst;		// hysteresis
  float		acc;		// fast accomodation
  bool		hyst_on;	// #NO_VIEW binary thresholded mode state variable, hyst
  bool		acc_on;		// #NO_VIEW binary thresholded mode state variable, acc
  float		g_h;		// #NO_VIEW hysteresis conductance
  float		g_a;		// #NO_VIEW accomodation conductance

  void	Initialize();
  void	Destroy()	{ };
  void 	Copy_(const VChanBasis& cp);
  COPY_FUNS(VChanBasis, taBase);
  TA_BASEFUNS(VChanBasis);
};

class ActFunSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER activation function specifications
public:
  float		thr;		// initial threshold value (prior to adaptation)
  float		gain;		// gain of the activation function (act_eq for spikes)
  float		nvar;		// variance of the gaussian noise for NOISY_XX1

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(ActFunSpec);
  COPY_FUNS(ActFunSpec, taBase);
  TA_BASEFUNS(ActFunSpec);
};

class SpikeFunSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER spiking activation function specs
public:
  int		dur;		// spike duration in cycles (models duration of effect on postsyn)
  float		v_m_r;		// post-spiking membrane potential to reset to (refractory)
  float		eq_gain;	// gain for computing act_eq relative to actual average
  float		ext_gain;	// gain for clamped external inputs (which are constant)

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(SpikeFunSpec);
  COPY_FUNS(SpikeFunSpec, taBase);
  TA_BASEFUNS(SpikeFunSpec);
};

class AdaptThreshSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER adapting threshold based on average act
public:
  float		a_dt;		// time constant for integrating activation average
  float		min;		// minimum avg act, above which no adaptation
  float		max;		// maximum avg act, below which no adaptation
  float		t_dt;		// time constant for integrating threshold changes
  float		mx_d;		// maximum amount to change threshold

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(AdaptThreshSpec);
  COPY_FUNS(AdaptThreshSpec, taBase);
  TA_BASEFUNS(AdaptThreshSpec);
};

class OptThreshSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER optimization thresholds for faster processing
public:
  float		send;		// threshold for sending activation value
  float		learn;		// threshold for learning (activation value)
  bool		updt_wts;	// whether to apply threshold to updating weights

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(OptThreshSpec);
  COPY_FUNS(OptThreshSpec, taBase);
  TA_BASEFUNS(OptThreshSpec);
};

class BioBelUnitSpec : public UnitSpec {
  // BioBel relative belief unit specifications
public:
  enum ActFun {
    NOISY_XX1,			// noisy version of x over x plus 1 (noise is nvar)
    XX1,			// x over x plus 1
    LINEAR,			// simple linear output function 
    SPIKE			// spiking activations
  };

  enum NoiseType {
    NO_NOISE,			// no noise added to processing
    VM_NOISE,			// noise in the value of v_m
    NETIN_NOISE,		// noise in the net input (g_e)
    ACT_NOISE			// noise in the activations
  };

  ActFun	act_fun;	// activation function to use
  ActFunSpec	act;		// specifications of the activation function
  SpikeFunSpec	spike;		// specifications of the spiking activation function
  AdaptThreshSpec adapt_thr;	// adapting threshold specifications
  OptThreshSpec	opt_thresh;	// optimization thresholds for faster processing
  MinMaxRange	clamp_range;	// range of clamped activation values
  MinMaxRange	vm_range;	// membrane potential range
  Random	v_m_init;	// what to initialize the membrane potential to
  float		vm_dt;		// step size to take in integrating the membrane potential
  float		net_dt;		// step size to take in integrating the net input
  BioBelChannels g_bar;		// scales value of conductances
  BioBelChannels e_rev;		// reversal potential associated with each conductance
  VChanSpec	hyst;		// hysteresis v-gated chan (Ca2+, NMDA)
  VChanSpec	acc;		// fast accomodation v-gated chan (delayed rectifier)
  NoiseType	noise_type;	// where to add noise in the processing
  Random	noise;		// what kind of noise?
  Schedule	noise_sched;	// schedule of noise variance over settling cycles
  FunLookup	nxx1_fun;	// #HIDDEN #NO_SAVE #NO_INHERIT convolved gaussian and x/x+1 function as lookup table
  FunLookup	noise_conv;	// #HIDDEN #NO_SAVE #NO_INHERIT gaussian for convolution

  void 		InitWtState(Unit* u);

  virtual void	InitState(BioBelUnit* u, BioBelLayer* lay);
  void		InitState(Unit* u)	{ UnitSpec::InitState(u); }
  virtual void	InitThresh(BioBelUnit* u);
  // initialize the threshold and act_avg back to original starting values

  virtual void	ReConnect_Load(BioBelUnit* u, BioBelLayer* lay);
  // #IGNORE update non-saved variables after loading network

  virtual void	CompToTarg(BioBelUnit* u, BioBelLayer* lay);
  // copy comparison external inputs to target ones
  virtual void 	Compute_NetScaleClamp(BioBelUnit* u, BioBelLayer* lay);
  // compute net input scaling values and input from hard-clamped inputs

  void 		Compute_Net(Unit* u) { UnitSpec::Compute_Net(u); }
  void 		Compute_Net(BioBelUnit* u, BioBelLayer* lay);
  // add ext input, send-based
  inline virtual void	Compute_NetAvg(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr);
  // compute netin average
  inline virtual void	Compute_InhibAvg(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr);
  // compute inhib netin average
  virtual void	Compute_HardClamp(BioBelUnit* u, BioBelLayer* lay);
  virtual bool	Compute_SoftClamp(BioBelUnit* u, BioBelLayer* lay);
  // soft-clamps unit, returns true if unit is not above .5

  void		Compute_Act(Unit* u)	{ UnitSpec::Compute_Act(u); }
  virtual void 	Compute_Act(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr, int cycle);
  // compute the final activation

  float		Compute_IThresh(BioBelUnit* u);
  // compute inhibitory value that would place unit directly at threshold

  virtual void	DecayState(BioBelUnit* u, BioBelLayer* lay, float decay);
  // decay activation states towards initial values

  virtual void	PostSettle(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr,
			   int phase, bool set_both=false);
  // set stuff after settling is over (place holder)

  virtual bool	AdaptThreshTest(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr);
  // compute long-term average activation, and test if thresh needs adapting
  virtual void	AdaptThresh(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr);
  // adapt the firing threshold based on long-term average activation

  virtual void	CreateNXX1Fun();  // create convolved gaussian and x/x+1 

  void	UpdateAfterEdit();	// to set _impl sig
  void 	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  SIMPLE_COPY(BioBelUnitSpec);
  COPY_FUNS(BioBelUnitSpec, UnitSpec);
  TA_BASEFUNS(BioBelUnitSpec);
};

class BioBelUnitChans : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER channels used in BioBel units
public:
  float		l;		// #NO_VIEW leak
  float		i;		// inhibitory
  float		h;		// hysteresis (Ca)
  float		a;		// accomodation (K)

  void	Initialize();
  void	Destroy()	{ };
  void 	Copy_(const BioBelUnitChans& cp);
  COPY_FUNS(BioBelUnitChans, taBase);
  TA_BASEFUNS(BioBelUnitChans);
};

class BioBelUnit : public Unit {
  // BioBel relative belief unit
public:
  float		clmp_net;	// #NO_VIEW #NO_SAVE hard-clamp net input (no need to recompute)
  float		net_scale;	// #NO_VIEW #NO_SAVE total netinput scaling basis
  float		prv_net;	// #NO_VIEW #NO_SAVE previous net input (for time averaging)
  float		prv_g_i;	// #NO_VIEW #NO_SAVE previous inhibitory cond val
  VChanBasis	vcb;		// voltage-gated channel basis variables
  BioBelUnitChans gc;		// #NO_SAVE current unit channel conductances
  float		I_net;		// #NO_SAVE net current produced by all channels
  float		v_m;		// #NO_SAVE membrane potential
  float		thr;		// threshold for firing (adaptive)
  float		da;		// #NO_SAVE delta activation
  float		act_eq;		// #NO_SAVE equilibrium activity value (accumulates effects of spikes)
  float		act_avg;	// average activation over long time intervals

  void		InitDelta() { net = gc.i = 0.0f; }
  void		InitState(BioBelLayer* lay)
  { ((BioBelUnitSpec*)spec.spec)->InitState(this, lay); }
  void		InitThresh()
  { ((BioBelUnitSpec*)spec.spec)->InitThresh(this); }

  void		ReConnect_Load(BioBelLayer* lay)	// #IGNORE
  { ((BioBelUnitSpec*)spec.spec)->ReConnect_Load(this, lay); }
       
  void		CompToTarg(BioBelLayer* lay)
  { ((BioBelUnitSpec*)spec.spec)->CompToTarg(this, lay); }
  void		Compute_NetScaleClamp(BioBelLayer* lay)
  { ((BioBelUnitSpec*)spec.spec)->Compute_NetScaleClamp(this, lay); }

  void		Compute_Net(BioBelLayer* lay)
  { ((BioBelUnitSpec*)spec.spec)->Compute_Net(this, lay); }
  void		Compute_NetAvg(BioBelLayer* lay, BioBelInhib* thr)
  { ((BioBelUnitSpec*)spec.spec)->Compute_NetAvg(this, lay, thr); }
  void		Compute_InhibAvg(BioBelLayer* lay, BioBelInhib* thr)
  { ((BioBelUnitSpec*)spec.spec)->Compute_InhibAvg(this, lay, thr); }
  void		Compute_HardClamp(BioBelLayer* lay) 
  { ((BioBelUnitSpec*)spec.spec)->Compute_HardClamp(this, lay); }
  bool		Compute_SoftClamp(BioBelLayer* lay) 
  { return ((BioBelUnitSpec*)spec.spec)->Compute_SoftClamp(this, lay); }

  void		Compute_Act()	{ Unit::Compute_Act(); }
  void 		Compute_Act(BioBelLayer* lay, BioBelInhib* thr, int cycle) 
  { ((BioBelUnitSpec*)spec.spec)->Compute_Act(this, lay, thr, cycle); }

  float		Compute_IThresh()
  { return ((BioBelUnitSpec*)spec.spec)->Compute_IThresh(this); }

  void		DecayState(BioBelLayer* lay, float decay)
  { ((BioBelUnitSpec*)spec.spec)->DecayState(this, lay, decay); }
  void		PostSettle(BioBelLayer* lay, BioBelInhib* thr, int phase, bool set_both=false)
  { ((BioBelUnitSpec*)spec.spec)->PostSettle(this, lay, thr, phase, set_both); }
  bool		AdaptThreshTest(BioBelLayer* lay, BioBelInhib* thr)
  { return ((BioBelUnitSpec*)spec.spec)->AdaptThreshTest(this, lay, thr); }
  void		AdaptThresh(BioBelLayer* lay, BioBelInhib* thr)
  { ((BioBelUnitSpec*)spec.spec)->AdaptThresh(this, lay, thr); }

  void 	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  SIMPLE_COPY(BioBelUnit);
  COPY_FUNS(BioBelUnit, Unit);
  TA_BASEFUNS(BioBelUnit);
};

class BioBelSort : public taPtrList<BioBelUnit> {
  // ##NO_TOKENS ##NO_UPDATE_AFTER used for sorting units in kwta computation
protected:
  int		El_Compare_(void* a, void* b) const
  { int rval=-1; if(((BioBelUnit*)a)->net < ((BioBelUnit*)b)->net) rval=1;
    else if(((BioBelUnit*)a)->net == ((BioBelUnit*)b)->net) rval=0; return rval; }
  // compare two items for purposes of sorting: descending order by net
public:
  int	FindNewNetPos(float nw_net);	  // find position in list for a new net value
  void	FastInsertLink(void* it, int where); // faster version of insert link fun
};

class LayerLink : public taOBase {
  // ##NO_TOKENS #NO_UPDATE_AFTER Link strength between layers, affects threshold
public:
  BioBelLayer*	layer;		// layer to link to
  float		link_wt;	// strength of the Link

  void	Initialize();
  void	Destroy()	{ CutLinks(); }
  void	CutLinks();
  void 	Copy_(const LayerLink& cp);
  COPY_FUNS(LayerLink, taOBase);
  TA_BASEFUNS(LayerLink);
};

class LayerLink_List : public taList<LayerLink> {
  // ##NO_TOKENS ##NO_UPDATE_AFTER list of LayerLink objects
public:
  void	Initialize() 		{ };
  void 	Destroy()		{ };
  TA_BASEFUNS(LayerLink_List);
};

// misc data-holding structures

class AvgMaxVals : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER holds average and max statistics
public:
  float		avg;	// average value
  float		max;	// maximum value
  
  void	Initialize();
  void 	Destroy()	{ };
  void	Copy_(const AvgMaxVals& cp) { avg = cp.avg; max = cp.max; }
  COPY_FUNS(AvgMaxVals, taBase);
  TA_BASEFUNS(AvgMaxVals);
};

class BioBelDecays : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER holds decay values
public:
  float		event;  // how much to decay between events
  float		phase;  // how much to decay between phases
  float		ae;
  // how much to decay for auto-encoder mode (between plus and nothing phases)

  void	Initialize();
  void 	Destroy()	{ };
  void	Copy_(const BioBelDecays& cp) { event = cp.event; phase = cp.phase; ae = cp.ae; }
  COPY_FUNS(BioBelDecays, taBase);
  TA_BASEFUNS(BioBelDecays);
};

class KWTASpec : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER holds parameters specifying kwta params
public:
  enum K_From {
    USE_K,			// use the k specified directly
    USE_PCT,			// use the percentage to compute the k
    USE_PAT_K			// use the activity level of the event pattern (>thresh)
  };

  K_From	k_from;		// how is the active_k determined?
  int		k;		// number of active units in the layer
  float		pct;		// desired proportion of activity 
  float		pat_q;		// #HIDDEN threshold for pat_k based activity level
  float		adth_pct;	// #HIDDEN what pct of k units can adapt threshold at one time

  void	Initialize();
  void 	Destroy()	{ };
  SIMPLE_COPY(KWTASpec);
  COPY_FUNS(KWTASpec, taBase);
  TA_BASEFUNS(KWTASpec);
};

class KWTAVals : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER holds values for kwta stuff
public:
  int		k;       	// target number of active units for this collection
  float		pct;		// actual percent activity in group
  float		pct_c;		// #HIDDEN complement of (1.0 - ) actual percent activity in group
  int		adth_k;		// #HIDDEN adapting threshold k value -- how many units can adapt per time

  void		Compute_Pct(int n_units);
  void		Compute_AdthK(float adth_pct);

  void	Initialize();
  void 	Destroy()	{ };
  void	Copy_(const KWTAVals& cp);
  COPY_FUNS(KWTAVals, taBase);
  TA_BASEFUNS(KWTAVals);
};

class ActInhibSpec : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER holds parameters for act-based inhibition
public:
  float		dt;		// rate constant for integrating inhibition
  float		gain;		// gain of activation to give inhibition

  void	Initialize();
  void 	Destroy()	{ };
  SIMPLE_COPY(ActInhibSpec);
  COPY_FUNS(ActInhibSpec, taBase);
  TA_BASEFUNS(ActInhibSpec);
};

class InhibVals : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER holds values for inhibition
public:
  float		kwta;		// inhibition due to kwta function
  float		stdev;		// inhibition due to standard deviation model
  float		sact;		// inhibition due to sending activation
  float		ract;		// inhibition due to sending activation
  float		g_i;		// overall value of the inhibition
  float		g_i_orig; 	// #HIDDEN original value of the inhibition (before linking)

  void	Initialize();
  void 	Destroy()	{ };
  void	Copy_(const InhibVals& cp);
  COPY_FUNS(InhibVals, taBase);
  TA_BASEFUNS(InhibVals);
};

class BioBelLayerSpec : public LayerSpec {
  // BioBel relative belief layer specs, computes inhibitory input for all units in layer
public:
  enum Compute_I {		// how to compute the inhibition
    KWTA_INHIB,			// between thresholds of k and k+1th
    KWTA_AVG_INHIB,		// average of top k vs avg of rest
    STDEV_INHIB,		// as function of standard deviation of inhib within layer
    SACT_INHIB,			// from sending activation
    RACT_INHIB,			// from recurrent activation
    SRACT_INHIB,		// from sending and recurrent activation
    UNIT_INHIB,			// unit-based inhibition (g_i from netinput)
  };

  enum InhibGroup {
    ENTIRE_LAYER,		// treat entire layer as one inhibitory group (even if subgroups exist)
    UNIT_GROUPS,		// treat sub unit groups as separate inhibitory groups
    LAY_AND_GPS			// compute inhib over both groups and whole layer
  };
  
  enum LayerLinking {
    NO_LINK,			// no linking
    LINK_INHIB			// link the inhibition
  };

  KWTASpec	kwta;		// how to calculate the desired activity level
  KWTASpec	gp_kwta;	// desired activity level for the unit groups (if applicable)
  Compute_I	compute_i;	// how to compute the inhibition
  float		i_kwta_pt;	// point to place inhibition between k and k+1 for kwta
  float		i_stdev_gain;	// gain of pct term to get inhib from area under normal above thresh
  ActInhibSpec 	i_sact;		// parameters for sending act based inhbition
  ActInhibSpec 	i_ract;		// parameters for recurrent act based inhbition
  bool		hard_clamp;	// whether to hard clamp any inputs to this layer or not
  float		stm_gain;	// minimum stimulus gain factor (when not hard clamping)
  float		d_stm_gain;	// delta to increase when target units not > .5
  BioBelDecays	decay;		// how much to decay the prior (towards initial_act)
  InhibGroup	inhib_group;	// what to consider the inhibitory group (layer or subgroups)
  LayerLinking	layer_link;	// how to link the layers (if links exist)
  float		layer_link_gain;
  // gain of the layer linking function, how much layer's thresh depends on others
  BioBelSort	adapt_thr_list;	// #HIDDEN #NO_SAVE #NO_INHERIT list of units needing thresh adapt

  virtual void	InitThresh(BioBelLayer* lay);
  // initialize the adapting threshold state values

  virtual void	Compute_HardClamp(BioBelLayer* lay, int phase);
  // prior to settling: hard-clamp inputs
  virtual int	Compute_InputDist(BioBelLayer* lay, int phase);
  // prior to settling: compute layer's distance from input
  virtual void	Compute_Cascade(BioBelLayer* lay, int phase, int depth);
  // compute cascading of activation based on target depth from input
  virtual void	Compute_NetScaleClamp(BioBelLayer* lay, int phase);
  // prior to settling: compute netinput scaling values and input from hard-clamped

  virtual void 	Compute_Net(BioBelLayer* lay, int cycle, int phase);
  // stage zero: compute net inputs

  virtual void	Compute_Clamp_NetAvg(BioBelLayer* lay, int cycle, int phase);
  // stage one: clamp and compute averages of net inputs that were already computed
  virtual void	Compute_NetAvg(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr,
			       int cycle, int phase);
  virtual void	Compute_sAct(BioBelLayer* lay, int cycle, int phase);
  // compute avg and max of sending activations into layer
  virtual void	Compute_SoftClamp(BioBelLayer* lay, int cycle, int phase);
  // soft-clamp inputs by adding to net input

  virtual void	InitInhib(BioBelLayer* lay);
  // initialize the inhibitory state values
  virtual void	Compute_Inhib(BioBelLayer* lay, int cycle, int phase);
  // stage two: compute the inhibition for layer
  virtual void	Compute_Inhib_impl(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of inhibition computation for either layer or unit group
  virtual void	Compute_Inhib_kWTA(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of kwta inhibition computation
  virtual void	Compute_Inhib_StDev(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of stdev inhibition computation
  virtual void	Compute_Inhib_sAct(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of sending activation based inhibition
  virtual void	Compute_Inhib_rAct(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of recurrent activation based inhibition
  virtual void	Compute_Inhib_Unit(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of inhibition based on inhibitory unit input
  virtual void	Compute_Inhib_kWTA_Avg(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);
  // implementation of kwta avg inhibition computation
  virtual void	Compute_LinkInhib(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr,
				   int cycle);
  // compute inhibition after linkages with other layers are factored in
  virtual void	Compute_Active_K(BioBelLayer* lay);
  virtual void	Compute_Active_K_impl(BioBelLayer* lay, Unit_Group* ug,
				      BioBelInhib* thr, KWTASpec& kwtspec);
  virtual int	Compute_Pat_K(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr);

  virtual void 	Compute_Act(BioBelLayer* lay, int cycle, int phase);
  // stage three: compute final activation
  virtual void 	Compute_Act_impl(BioBelLayer* lay, Unit_Group* ug, BioBelInhib* thr,
				 int cycle, int phase);

  virtual void	DecayEvent(BioBelLayer* lay);
  virtual void	DecayPhase(BioBelLayer* lay);
  virtual void	DecayAE(BioBelLayer* lay);

  virtual void	CompToTarg(BioBelLayer* lay);
  // change comparison external inputs into target external inputs
  virtual void	PostSettle(BioBelLayer* lay, int phase, bool set_both=false);
  // after settling, keep track of phase variables, etc.
  virtual void	AdaptThreshold(BioBelLayer* lay);
  // adapt the thresholds of units based on average activity

  void	UpdateAfterEdit();
  void 	Initialize();
  void	Destroy()		{ CutLinks(); }
  void	InitLinks();
  void	CutLinks();
  SIMPLE_COPY(BioBelLayerSpec);
  COPY_FUNS(BioBelLayerSpec, LayerSpec);
  TA_BASEFUNS(BioBelLayerSpec);
};

SpecPtr_of(BioBelLayerSpec);

class BioBelInhib {
  // holds threshold-computation values, used as a parent class for layers, etc
public:
  BioBelSort 	active_buf;	// #HIDDEN #NO_SAVE list of active units
  BioBelSort 	inact_buf;	// #HIDDEN #NO_SAVE list of inactive units

  AvgMaxVals	netin;		// net input values for the layer
  AvgMaxVals	acts;		// activation values for the layer
 
  KWTAVals	kwta;		// values for kwta -- activity levels, etc
  InhibVals	i_val;		// inhibitory values
  AvgMaxVals	un_g_i;		// average and stdev (not max) values for unit inhib-to-thresh

  void	Inhib_SetVals(float val)	{ i_val.g_i = val; i_val.g_i_orig = val; }
  void	Inhib_ResetSortBuf() 		{ active_buf.size = 0; inact_buf.size = 0; }
  void	Inhib_InitState(BioBelLayerSpec* lay);
  void	Inhib_Initialize();
  void	Inhib_Copy_(const BioBelInhib& cp);
};

class BioBelLayer : public Layer, public BioBelInhib {
  // BioBel Layer: implicit inhibition for soft kWTA behavior
public:
  AvgMaxVals	sact;		// sending activation values (avg and max, weighted by wt_scale)
  BioBelLayerSpec_SPtr	spec;	// the spec for this layer
  LayerLink_List layer_links;	// list of layers to link inhibition with
  float		stm_gain;	// actual stim gain (failsafe stm_gain for soft clamping)
  bool		hard_clamped;	// this layer is actually hard clamped
  int	        input_dist;	// number of layers away from external input

  void		Build();
  void		InitState();  	// initialize layer state too
  void		InitWtState();
  void		InitThresh() 	{ spec->InitThresh(this); } // initialize adapting thresholds
  void		InitInhib() 	{ spec->InitInhib(this); } // initialize inhibitory state
  void		ModifyState()	{ spec->DecayEvent(this); } // this is what modify means..

  void		ReConnect_Load(); // #IGNORE also call stuff at unit level

  void	Compute_HardClamp(int phase)  	{ spec->Compute_HardClamp(this, phase); }
  int	Compute_InputDist(int phase)	{ return spec->Compute_InputDist(this, phase); }
  void	Compute_Cascade(int phase, int depth) { spec->Compute_Cascade(this, phase, depth); }
  void	Compute_NetScaleClamp(int phase) { spec->Compute_NetScaleClamp(this, phase); }

  void	Compute_Net()			{ spec->Compute_Net(this, -1, 0); }
  void	Compute_Net(int cycle, int phase)
  { spec->Compute_Net(this, cycle, phase); }

  void	Compute_Clamp_NetAvg(int cycle, int phase)
  { spec->Compute_Clamp_NetAvg(this, cycle, phase); }
  void	Compute_Inhib(int cycle, int phase)
  { spec->Compute_Inhib(this, cycle, phase); }
  void	Compute_Act()			{ spec->Compute_Act(this, -1, 0); }
  void	Compute_Act(int cycle, int phase) { spec->Compute_Act(this, cycle, phase); }
  void	Compute_Active_K()		{ spec->Compute_Active_K(this); }

  void	DecayEvent()	{ spec->DecayEvent(this); } // decay between events
  void	DecayPhase()    { spec->DecayPhase(this); } // decay between phases
  void	DecayAE()  	{ spec->DecayAE(this); }    // decay for auto-encoder

  void	CompToTarg()		{ spec->CompToTarg(this); }
  void	PostSettle(int phase, bool set_both=false)	{ spec->PostSettle(this, phase, set_both); }

  virtual void	ResetSortBuf();

  bool		SetLayerSpec(LayerSpec* sp);
  LayerSpec*	GetLayerSpec()		{ return (LayerSpec*)spec.spec; }

  void	UpdateAfterEdit();	// reset sort_buf after any edits..

  void	Initialize();
  void	Destroy()		{ CutLinks(); }
  void	InitLinks();
  void	CutLinks();
  void	Copy_(const BioBelLayer& cp);
  COPY_FUNS(BioBelLayer, Layer);
  TA_BASEFUNS(BioBelLayer);
};

class BioBelUnit_Group : public Unit_Group, public BioBelInhib {
  // for independent subgroups of competing units within a single layer
public:

  void	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  TA_BASEFUNS(BioBelUnit_Group);
};

// inlines

void BioBelConSpec::C_InitWtState_post(Con_Group* cg, Connection* cn, Unit*, Unit*) {
  C_Compute_LinFmWt((BioBelCon_Group*)cg, (BioBelCon*)cn);
}

void BioBelConSpec::Compute_LinFmWt(BioBelCon_Group* cg) {
  CON_GROUP_LOOP(cg, C_Compute_LinFmWt(cg, (BioBelCon*)cg->Cn(i)));
}

void BioBelConSpec::Compute_WtFmLin(BioBelCon_Group* cg) {
  CON_GROUP_LOOP(cg, C_Compute_WtFmLin(cg, (BioBelCon*)cg->Cn(i)));
}

float BioBelConSpec::C_Compute_Net(BioBelCon* cn, Unit*, Unit* su) {
  return cn->wt * su->act;
}
float BioBelConSpec::Compute_Net(Con_Group* cg, Unit* ru) {
  float rval=0.0f;
  CON_GROUP_LOOP(cg, rval += C_Compute_Net((BioBelCon*)cg->Cn(i), ru, cg->Un(i)));
  return ((BioBelCon_Group*)cg)->scale_eff * rval;
}

void BioBelConSpec::C_Send_Net(BioBelCon_Group* cg, BioBelCon* cn, Unit* ru, Unit* su) {
  ru->net += ((BioBelCon_Group*)ru->recv.Gp(cg->other_idx))->scale_eff * su->act * cn->wt;
}
void BioBelConSpec::Send_Net(Con_Group* cg, Unit* su) {
  if(inhib)
    Send_Inhib((BioBelCon_Group*)cg, (BioBelUnit*)su);
  else {
    CON_GROUP_LOOP(cg, C_Send_Net((BioBelCon_Group*)cg, (BioBelCon*)cg->Cn(i), cg->Un(i), su));
  }
}

void BioBelConSpec::C_Send_Inhib(BioBelCon_Group* cg, BioBelCon* cn, BioBelUnit* ru,
				 BioBelUnit* su) {
  ru->gc.i += ((BioBelCon_Group*)ru->recv.Gp(cg->other_idx))->scale_eff * su->act * cn->wt;
}
void BioBelConSpec::Send_Inhib(BioBelCon_Group* cg, BioBelUnit* su) {
  CON_GROUP_LOOP(cg, C_Send_Inhib((BioBelCon_Group*)cg, (BioBelCon*)cg->Cn(i), 
				  (BioBelUnit*)cg->Un(i), su));
}

// time-average netinput accumulation
void BioBelUnitSpec::Compute_NetAvg(BioBelUnit* u, BioBelLayer*, BioBelInhib*) {
  u->net *= g_bar.e;		// multiply by gbar..
  u->net = u->prv_net + net_dt * (u->net - u->prv_net);
  u->prv_net = u->net;
}

void BioBelUnitSpec::Compute_InhibAvg(BioBelUnit* u, BioBelLayer*, BioBelInhib*) {
  u->gc.i *= g_bar.i;		// multiply by gbar..
  u->gc.i = u->prv_g_i + net_dt * (u->gc.i - u->prv_g_i);
  u->prv_g_i = u->gc.i;
}


//////////////////////////
// 	Processes	//
//////////////////////////

// see leabra.h,cc for examples of BioBel processes

#endif // biobel_h
