/* -*- C++ -*- */
/*=============================================================================
//									      //
// This file is part of the PDP++ software package.			      //
//									      //
// Copyright (C) 1995 Randall C. O'Reilly, Chadley K. Dawson, 		      //
//		      James L. McClelland, and Carnegie Mellon University     //
//     									      //
// Permission to use, copy, and modify this software and its documentation    //
// for any purpose other than distribution-for-profit is hereby granted	      //
// without fee, provided that the above copyright notice and this permission  //
// notice appear in all copies of the software and related documentation.     //
//									      //
// Permission to distribute the software or modified or extended versions     //
// thereof on a not-for-profit basis is explicitly granted, under the above   //
// conditions. 	HOWEVER, THE RIGHT TO DISTRIBUTE THE SOFTWARE OR MODIFIED OR  //
// EXTENDED VERSIONS THEREOF FOR PROFIT IS *NOT* GRANTED EXCEPT BY PRIOR      //
// ARRANGEMENT AND WRITTEN CONSENT OF THE COPYRIGHT HOLDERS.                  //
// 									      //
// Note that the taString class, which is derived from the GNU String class,  //
// is Copyright (C) 1988 Free Software Foundation, written by Doug Lea, and   //
// is covered by the GNU General Public License, see ta_string.h.             //
// The iv_graphic library and some iv_misc classes were derived from the      //
// InterViews morpher example and other InterViews code, which is             //
// Copyright (C) 1987, 1988, 1989, 1990, 1991 Stanford University             //
// Copyright (C) 1991 Silicon Graphics, Inc.				      //
//									      //
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,         //
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 	      //
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  	      //
// 									      //
// IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY BE LIABLE FOR ANY SPECIAL,    //
// INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES  //
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT     //
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,      //
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS        //
// SOFTWARE. 								      //
==============================================================================*/

// leabra.h 

#ifndef leabra_h
#ifdef __GNUG__
#pragma interface
#endif
#define leabra_h

#include <leabra/biobel.h>
#include <leabra/leabra_TA_type.h>

class LeabraCon;
class LeabraConSpec;
class LeabraBiasSpec;
class LeabraCon_Group;

class LeabraUnitSpec;
class LeabraUnit;
class LeabraLayer;
class LeabraLayerSpec;
class LeabraCycle;
class LeabraSettle;
class LeabraTrial;

class LeabraCon : public BioBelCon {
  // LEABRA connection
public:
  float		dwt;		// #NO_VIEW #NO_SAVE resulting net weight change
  float		pdw;		// #NO_SAVE previous delta-weight change

  void 	Initialize()		{ dwt = pdw = 0.0f; }
  void	Destroy()		{ };
  void	Copy_(const LeabraCon& cp);
  COPY_FUNS(LeabraCon, BioBelCon);
  TA_BASEFUNS(LeabraCon);
};

class LearnMixSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER mixture of learning factors specification
public:
  float		hebb;		// amount of hebbian learning
  float		err;		// amount of error driven learning

  void	UpdateAfterEdit();
  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(LearnMixSpec);
  COPY_FUNS(LearnMixSpec, taBase);
  TA_BASEFUNS(LearnMixSpec);
};

class SAvgCorSpec : public taBase {
  // ##INLINE ##NO_TOKENS #NO_UPDATE_AFTER sending average activation correction specifications
public:
  enum SAvgSource {
    SLAYER_AVG_ACT,
    SLAYER_TRG_PCT,
    FIXED_SAVG,
    COMPUTED_SAVG		// average over particular inputs is computed directly
  };

  float		cor;		// amount of correction to apply (0=none, 1=all, .5=half, etc)
  SAvgSource	src;		// source of sending average act for correcting computation of psr
  float		thresh;		// threshold below which learning does not occur

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(SAvgCorSpec);
  COPY_FUNS(SAvgCorSpec, taBase);
  TA_BASEFUNS(SAvgCorSpec);
};

class LeabraConSpec : public BioBelConSpec {
  // LEABRA connection specs, linear probability of sender given receiver
public:

  float		lrate;		// learning rate
  LearnMixSpec	lmix;		// mixture of learning factors (hebbian, error) 
  SAvgCorSpec	savg_cor;	// correction for sending average activation levels in hebbian

  void 		C_InitWtState(Con_Group* cg, Connection* cn, Unit* ru, Unit* su) {
    BioBelConSpec::C_InitWtState(cg, cn, ru, su); LeabraCon* lcn = (LeabraCon*)cn;
    lcn->pdw = 0.0f; }

  void 		C_InitWtDelta(Con_Group* cg, Connection* cn, Unit* ru, Unit* su)
  { BioBelConSpec::C_InitWtDelta(cg, cn, ru, su); ((LeabraCon*)cn)->dwt=0.0f; }

  inline void	Compute_SAvgCor(LeabraCon_Group* cg, LeabraUnit* ru);
  // compute hebb correction scaling terms for sending average act, returns inc cor, and dec cor

  // all of learning operates on wt_lin now, not wt!
  inline float	C_Compute_Hebb(LeabraCon* cn, LeabraCon_Group* cg,
			       float ru_act, float su_act);
  // compute Hebbian associative learning

  inline float 	C_Compute_Err(LeabraCon*, float ru_act_p, float ru_act_m,
				  float su_act_p, float su_act_m);
  // compute generec error term, sigmoid case

  inline void 	C_Compute_dWt(LeabraCon* cn, float heb, float err);
  // combine associative and error-driven weight change, actually update dwt

  inline void 	Compute_dWt(Con_Group* cg, Unit* ru);
  // compute weight change: make new one of these for any C_ change above: hebb, err, dwt

  inline virtual void	B_Compute_dWt(LeabraCon* cn, LeabraUnit* ru);
  // compute bias weight change for netin model of bias weight

  inline void		C_UpdateWeights(LeabraCon* cn, LeabraCon_Group* cg, 
					LeabraUnit* ru, LeabraUnit* su);
  inline void		UpdateWeights(Con_Group* cg, Unit* ru);
  inline virtual void	B_UpdateWeights(LeabraCon* cn, LeabraUnit* ru);

  void	UpdateAfterEdit();
  void 	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  SIMPLE_COPY(LeabraConSpec);
  COPY_FUNS(LeabraConSpec, BioBelConSpec);
  TA_BASEFUNS(LeabraConSpec);
};

class LeabraBiasSpec : public LeabraConSpec {
  // LEABRA bias-weight connection specs (bias wts are a little bit special)
public:
  float		dwt_thresh;
  // don't change wts if dwt < thresh (should be same as learn_thresh)

  inline void	B_UpdateWeights(LeabraCon* cn, LeabraUnit* ru);

  void 	Initialize();
  void	Destroy()		{ };
  SIMPLE_COPY(LeabraBiasSpec);
  COPY_FUNS(LeabraBiasSpec, LeabraConSpec);
  TA_BASEFUNS(LeabraBiasSpec);
};

class LeabraCon_Group : public BioBelCon_Group {
  // standard LEABRA connection group
public:
  float		savg;		// #NO_SAVE sending average activation
  float		max_cor;	// #NO_SAVE savg correction factor for psr_max_cor

  virtual void	EncodeState(LeabraUnit*) { };
  // encode current state information (hook for time-based learning)

  void 	Initialize();
  void	Destroy()		{ };
  TA_BASEFUNS(LeabraCon_Group);
};

class LeabraUnitSpec : public BioBelUnitSpec {
  // standard LEABRA unit specs
public:
  float		phase_dif_thresh;
  // threshold for phase differences (ratio -/+) for learning

  void 		InitWtState(Unit* u);

  virtual void	PhaseInit(BioBelUnit* u, BioBelLayer* lay, int phase);
  // initialize external input flags based on phase
  void		PostSettle(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr,
			   int phase, bool set_both=false);
  // set stuff after settling is over (set_both = both _m and _p for current)

  virtual void	Compute_dWt_impl(LeabraUnit* u, LeabraLayer* lay);
  // actually do wt change
  void		Compute_dWt(Unit*)	{ };
  virtual void	Compute_dWt(LeabraUnit* u, LeabraLayer* lay);

  virtual void	Compute_dWt_post(LeabraUnit* u, LeabraLayer* lay);
  // after computing the weight changes (for recon delta)

  //  void		AdaptThresh(BioBelUnit* u, BioBelLayer* lay, BioBelInhib* thr, int phase);

  void		UpdateWeights(Unit* u);

  virtual void	EncodeState(LeabraUnit*, LeabraLayer*)	{ };
  // encode current state information (hook for time-based learning)

  void	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  SIMPLE_COPY(LeabraUnitSpec);
  COPY_FUNS(LeabraUnitSpec, BioBelUnitSpec);
  TA_BASEFUNS(LeabraUnitSpec);
};

class LeabraUnit : public BioBelUnit {
  // standard LEABRA unit
public:
  float		act_dif;	// difference between plus and minus phase acts
  float		act_m;		// minus_phase activation
  float		act_p;		// plus_phase activation

  void		PhaseInit(BioBelLayer* lay, int phase)
  { ((LeabraUnitSpec*)spec.spec)->PhaseInit(this, lay, phase); }

  void 		Compute_dWt(LeabraLayer* lay)
  { ((LeabraUnitSpec*)spec.spec)->Compute_dWt(this, lay); }	  

  void 		Compute_dWt_post(LeabraLayer* lay) 
  { ((LeabraUnitSpec*)spec.spec)->Compute_dWt_post(this, lay); }

  void 		EncodeState(LeabraLayer* lay) 
  { ((LeabraUnitSpec*)spec.spec)->EncodeState(this, lay); }

  void	Initialize();
  void	Destroy()		{ };
  void 	InitLinks();
  SIMPLE_COPY(LeabraUnit);
  COPY_FUNS(LeabraUnit, BioBelUnit);
  TA_BASEFUNS(LeabraUnit);
};

class LeabraLayerSpec : public BioBelLayerSpec {
  // LEABRA layer specifications
public:
  virtual void	PhaseInit(BioBelLayer* lay, int phase);
  // initialize start of a setting phase, set input flags appropriately, etc

  void	PostSettle(BioBelLayer* lay, int phase, bool set_both=false);
  // after settling, keep track of phase variables, etc.

  virtual void	Compute_dWt_post(LeabraLayer* lay);
  // something to be done after the weights are changed (i.e. update history..)

  void 	Initialize();
  void	Destroy()		{ };
  TA_BASEFUNS(LeabraLayerSpec);
};

class LeabraContextLayerSpec : public LeabraLayerSpec {
  // context layer that copies from its recv projection (like an input layer)
public:
  float		hysteresis;	 // hysteresis factor: (1-hyst)*new + hyst*old
  float		hysteresis_c;	 // #READ_ONLY complement of hysteresis

  void	Compute_HardClamp(BioBelLayer* lay, int phase);
  // clamp from act_p values of sending layer

  void	UpdateAfterEdit();
  void 	Initialize();
  void	Destroy()		{ };
  SIMPLE_COPY(LeabraContextLayerSpec);
  COPY_FUNS(LeabraContextLayerSpec, LeabraLayerSpec);
  TA_BASEFUNS(LeabraContextLayerSpec);
};

class LeabraLayer : public BioBelLayer {
  // LEABRA layer 
public:
  AvgMaxVals	acts_p;		// plus-phase activation stats for the layer
  AvgMaxVals	acts_m;		// minus-phase activation stats for the layer
  AvgMaxVals	acts_dif;	// difference between p and m phases
  float		phase_dif_ratio; // phase-difference ratio (-avg / +avg)

  void	PhaseInit(int phase)	
  { ((LeabraLayerSpec*)spec.spec)->PhaseInit(this, phase); }

  void	Compute_dWt();
  void	Compute_dWt_post()
  { ((LeabraLayerSpec*)spec.spec)->Compute_dWt_post(this); }

  void	Initialize();
  void	Destroy()		{ };
  void 	InitLinks();
  SIMPLE_COPY(LeabraLayer);
  COPY_FUNS(LeabraLayer, BioBelLayer);
  TA_BASEFUNS(LeabraLayer);
};

//////////////////////////
//     Computing dWt 	//
//////////////////////////

inline void LeabraConSpec::Compute_SAvgCor(LeabraCon_Group* cg, LeabraUnit*) {
  LeabraLayer* fm = (LeabraLayer*)cg->prjn->from;
  if(savg_cor.src == SAvgCorSpec::SLAYER_TRG_PCT)
    cg->savg = fm->kwta.pct;
  else if(savg_cor.src == SAvgCorSpec::SLAYER_AVG_ACT)
    cg->savg = fm->acts_p.avg;
  else if(savg_cor.src == SAvgCorSpec::COMPUTED_SAVG) {
    cg->savg = 0.0f;
    for(int i=0; i<cg->size; i++)
      cg->savg += ((LeabraUnit*)cg->Un(i))->act_p;
    if(cg->size > 0)
      cg->savg /= (float)cg->size;
  }
  else
    cg->savg = fix_savg.savg;
  // bias savg based on k_savg_cor
  float savg = .5f + savg_cor.cor * (cg->savg - .5f);
  savg = MAX(savg_cor.thresh, savg); // keep this computed value within bounds
  cg->max_cor = .5f / savg;
}

inline float LeabraConSpec::C_Compute_Hebb(LeabraCon* cn, LeabraCon_Group* cg,
					   float ru_act, float su_act)
{
  return ru_act * (su_act * (cg->max_cor - cn->wt_lin) -
		   (1.0f - su_act) * cn->wt_lin);
}

// generec error term with sigmoid activation function, and soft bounding
inline float LeabraConSpec::C_Compute_Err
(LeabraCon* cn, float ru_act_p, float ru_act_m, float su_act_p, float su_act_m) {
  float err = (ru_act_p * su_act_p) - (ru_act_m * su_act_m);
  if(err > 0.0f)	err *= (1.0f - cn->wt_lin);
  else			err *= cn->wt_lin;	
  return err;
}

// combine hebbian and error-driven
inline void LeabraConSpec::C_Compute_dWt(LeabraCon* cn, float heb, float err) {
  float dwt = lmix.err * err + lmix.hebb * heb;
  cn->dwt += dwt;
}

inline void LeabraConSpec::Compute_dWt(Con_Group* cg, Unit* ru) {
  LeabraUnit* lru = (LeabraUnit*)ru;
  LeabraCon_Group* lcg = (LeabraCon_Group*) cg;
  Compute_SAvgCor(lcg, lru);
  if(lcg->savg >= savg_cor.thresh) {
    for(int i=0; i<cg->size; i++) {
      LeabraUnit* su = (LeabraUnit*)cg->Un(i);
      LeabraCon* cn = (LeabraCon*)cg->Cn(i);
      C_Compute_dWt(cn,
		    C_Compute_Hebb(cn, lcg, lru->act_p, su->act_p),
		    C_Compute_Err(cn, lru->act_p, lru->act_m, su->act_p, su->act_m));  
    }
  }
}

inline void LeabraConSpec::C_UpdateWeights(LeabraCon* cn, LeabraCon_Group* cg,
					   LeabraUnit*, LeabraUnit*)
{
  cn->wt_lin += lrate * cn->dwt;
  cn->wt_lin = MAX(cn->wt_lin, 0.0f);	// limit 0-1
  cn->wt_lin = MIN(cn->wt_lin, 1.0f);
  C_Compute_WtFmLin(cg, cn);
  cn->pdw = cn->dwt;
  cn->dwt = 0.0f;
}

inline void LeabraConSpec::UpdateWeights(Con_Group* cg, Unit* ru) {
  LeabraCon_Group* lcg = (LeabraCon_Group*)cg;
  CON_GROUP_LOOP(cg, C_UpdateWeights((LeabraCon*)cg->Cn(i), lcg,
				     (LeabraUnit*)ru, (LeabraUnit*)cg->Un(i)));
//  ApplyLimits(cg, ru); limits are automatically enforced anyway
}

inline void LeabraConSpec::B_Compute_dWt(LeabraCon* cn, LeabraUnit* ru) {
  cn->dwt += (ru->act_p - ru->act_m);
}
  
// default is not to do anything tricky with the bias weights
inline void LeabraConSpec::B_UpdateWeights(LeabraCon* cn, LeabraUnit* ru) {
  cn->pdw = cn->dwt;
  cn->wt += lrate * cn->dwt;
  cn->dwt = 0.0f;
  C_ApplyLimits(cn, ru, NULL);
}

inline void LeabraBiasSpec::B_UpdateWeights(LeabraCon* cn, LeabraUnit* ru) {
  if(fabsf(cn->dwt) < dwt_thresh)
    cn->dwt = 0.0f;
  cn->pdw = cn->dwt;
  cn->wt += lrate * cn->dwt;
  cn->dwt = 0.0f;
  C_ApplyLimits(cn, ru, NULL);
}

//////////////////////////
// 	Processes	//
//////////////////////////

class LeabraCycle : public CycleProcess {
  // one Leabra relative belief cycle of activation updating
public:
  LeabraSettle*	leabra_settle;
  // #NO_SUBTYPE #READ_ONLY #NO_SAVE pointer to parent settle proc

  void		Loop();		// compute activations
  bool 		Crit()		{ return true; } // executes loop only once
  
  virtual void	Compute_Net();
  virtual void	Compute_Clamp_NetAvg();
  virtual void	Compute_Inhib();
  virtual void	Compute_Act();

  void 	UpdateAfterEdit();		// modify to update the leabra_trial
  void 	Initialize();
  void 	Destroy()		{ CutLinks(); }
  void	CutLinks();
  SIMPLE_COPY(LeabraCycle);
  COPY_FUNS(LeabraCycle, CycleProcess);
  TA_BASEFUNS(LeabraCycle);
};

class CascadeParams : public taBase {
  // #INLINE ##NO_TOKENS #NO_UPDATE_AFTER Holds cascading parameters
public:
  int		cycles;		// number of cycles per cascade
  int		depth;
  // #IV_READ_ONLY #SHOW depth of cascading of information through net
  int		max; 		// maximum depth of network

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(CascadeParams);
  COPY_FUNS(CascadeParams, taBase);
  TA_BASEFUNS(CascadeParams);
};

class LeabraSettle : public SettleProcess {
  // Leabra relative belief settling phase of activation updating
public:
  LeabraTrial* 	leabra_trial;
  // #NO_SUBTYPE #READ_ONLY #NO_SAVE pointer to parent phase trial
  int		min_cycles;	// minimum number of cycles to settle for
  bool		use_cascade; 	// whether to use cascading activations or not
  CascadeParams	cascade;
  // #CONTROL_PANEL parameters controling cascading of info through net

  void		Init_impl();	// initialize start of settling
  void		Loop();		// do cascading in loop
  void		Final();	// update acts at end of settling

  virtual void	Compute_Active_K();
  virtual void	DecayEvent();
  virtual void	DecayPhase();
  virtual void	DecayAE();
  virtual void	PhaseInit();
  virtual void	CompToTarg();	// move COMPARE to TARGET (for + phase)
  virtual void	ExtToComp();	// move all env input to COMPARE (for final minus)
  virtual void	Compute_HardClamp();
  virtual void	Compute_InputDist();
  virtual void	Compute_Cascade();
  virtual void	Compute_NetScaleClamp();
  virtual void	PostSettle();
  virtual void	Compute_dWt();

  void 	UpdateAfterEdit();		// modify to update the leabra_trial
  void 	Initialize();
  void 	Destroy()		{ CutLinks(); }
  void	InitLinks();
  void	CutLinks();
  SIMPLE_COPY(LeabraSettle);
  COPY_FUNS(LeabraSettle, SettleProcess);
  TA_BASEFUNS(LeabraSettle);
};

class LeabraTrial : public TrialProcess {
  // Leabra relative belief trial process, iterates over phases
public:
  enum StateInit {		// ways of initializing the state of the network
    DO_NOTHING,			// do nothing
    INIT_STATE,			// initialize state
    DECAY_STATE			// decay the state
  };
    
  enum Phase {
    MINUS_PHASE = 0,		// minus phase
    PLUS_PHASE = 1		// plus phase
  };

  enum PhaseOrder {
    MINUS_PLUS,			// standard minus-plus (err and assoc)
    PLUS_ONLY,			// only present the plus phase (hebbian-only)
    MINUS_PLUS_NOTHING,		// auto-encoder version with final 'nothing' minus phase
    PLUS_NOTHING		// just the auto-encoder (no initial minus phase)
  };

  PhaseOrder	phase_order;	// number and order of phases to present
  Counter	phase_no;	// Current phase number
  Phase		phase;		// state variable for phase
  StateInit	trial_init;	// how to initialize network state at start of trial
  bool		no_plus_stats;	// don't do stats/logging in the plus phase
  bool		no_plus_test; 	// don't run the plus phase when testing

  void		C_Code();	// modify to use the no_plus_stats flag
  
  void		Init_impl();
  void		UpdateState();
  void		Final();
  bool		Crit()		{ return SchedProcess::Crit(); }

  virtual void	InitThresh();
  // #BUTTON #CONFIRM initialize the adapting activation thresholds

  virtual void	InitState();
  virtual void	DecayState();
  virtual void	EncodeState();
  virtual void	Compute_dWt_post();
  virtual void	Compute_dWt();

  void		GetCntrDataItems();
  void		GenCntrLog(LogData* ld, bool gen);

  void	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  void	Copy_(const LeabraTrial& cp);
  COPY_FUNS(LeabraTrial, TrialProcess);
  TA_BASEFUNS(LeabraTrial);
};

//////////////////////////
// 	Stats 		//
//////////////////////////

class BioBelMaxDa : public Stat {
  // ##COMPUTE_IN_SettleProcess ##LOOP_STAT stat that computes when equilibrium is
public:
  enum dAType {
    DA_ONLY,			// just use da
    INET_ONLY,			// just use inet
    INET_DA			// use inet if no activity, then use da
  };

  LeabraSettle* settle_proc;	// #READ_ONLY #NO_SAVE the settle process
  dAType	da_type;	// type of activation change measure to use
  float		inet_scale;	// how to scale the inet measure to be like da
  float		lay_avg_thr;	// threshold for layer average activation to switch to da fm Inet
  StatVal	da;		// absolute value of activation change

  void		RecvCon_Run(Unit*)	{}; // don't do these!
  void		SendCon_Run(Unit*)	{};

  void		InitStat();
  void		Init();
  bool		Crit();
  void		Network_Init();

  void 		Unit_Stat(Unit* unit);
  void		Network_Stat();	// check cascade depth and set to above thresh

  void	UpdateAfterEdit();
  void 	Initialize();		// set minimums
  void	Destroy()		{ CutLinks(); }
  void	CutLinks();
  SIMPLE_COPY(BioBelMaxDa);
  COPY_FUNS(BioBelMaxDa, Stat);
  TA_BASEFUNS(BioBelMaxDa);
};

class LeabraAeSE_Stat : public SE_Stat {
  // squared error for leabra auto-encoder: targ = minus, comp = nothing, both = both
public:
  LeabraTrial* 	trial_proc;	// #READ_ONLY #NO_SAVE the trial process to get phase info
  Unit::ExtType	targ_or_comp;	// which unit values to compute SE of

  void		Network_Run();	// only run in certain phases based on targ_or_comp
  void		Init();		// only init at the right time too
  void 		Unit_Stat(Unit* unit);
  void		NameStatVals();
  
  void	UpdateAfterEdit();
  void	Initialize();
  void	Destroy()		{ CutLinks(); }
  void	CutLinks();
  SIMPLE_COPY(LeabraAeSE_Stat);
  COPY_FUNS(LeabraAeSE_Stat, SE_Stat);
  TA_BASEFUNS(LeabraAeSE_Stat);
};

class LeabraGoodStat : public Stat {
  // ##COMPUTE_IN_TrialProcess constraint satisfaction goodness statistic
public:
  bool		subtr_inhib;	// subtract inhibition from harmony?
  StatVal	hrmny;
  StatVal	strss;
  StatVal	gdnss;

  void		InitStat();
  void		Init();
  bool		Crit();

  void		RecvCon_Run(Unit*)	{ }; // don't do these!
  void		SendCon_Run(Unit*)	{ };

  void		Network_Init();
  void		Unit_Stat(Unit* un);
  void		Network_Stat();

  void	Initialize();
  void	Destroy();
  void	Copy_(const LeabraGoodStat& cp);
  COPY_FUNS(LeabraGoodStat, Stat);
  TA_BASEFUNS(LeabraGoodStat);
};

//////////////////////////////////////////
// 	Encode/Learn Environment	//
//////////////////////////////////////////

class EncLrnEventSpec : public EventSpec {
  // explicit encoding and learning event spec for controling learning
public:
  enum EncLrnMode {
    IGNORE,			// do not encode or learn on this event
    ENCODE,			// encode this event (store activations) but don't learn
    LEARN,			// learn from this event, but don't encode new state
    LRN_ENC			// both learn and encode from this event
  };

  EncLrnMode	enc_lrn;	// what to do with this event: ignore, encode or learn

  void	Initialize();
  void	Destroy()	{ };
  void	Copy_(const EncLrnEventSpec& cp);
  COPY_FUNS(EncLrnEventSpec, EventSpec);
  TA_BASEFUNS(EncLrnEventSpec);
};

//////////////////////////////////////////
// 	Phase-Order  Environment	//
//////////////////////////////////////////

class PhaseOrderEventSpec : public EventSpec {
  // event specification including order of phases
public:
  enum PhaseOrder {
    MINUS_PLUS,			// minus phase, then plus phase
    PLUS_MINUS,			// plus phase, then minus phase
    PREV_PLUS_MINUS,		// use previous plus phase, only present minus
    PREV_MINUS_PLUS		// use previous minus phase, only present plus
  };

  PhaseOrder	phase_order;	// order to present phases of stimuli to network

  void	Initialize();
  void	Destroy() 	{ };
  void	Copy_(const PhaseOrderEventSpec& cp);
  COPY_FUNS(PhaseOrderEventSpec, EventSpec);
  TA_BASEFUNS(PhaseOrderEventSpec);
};

//////////////////////////////////////////
// 	Duration  Environment		//
//////////////////////////////////////////

class DurEvent : public Event {
  // an event which lasts for a particular amount of time
public:
  float		duration;	// #ENVIROVIEW length of time (cycles) event should be presented

  void 	Initialize();
  void	Destroy()		{ };
  void	Copy_(const DurEvent& cp);
  COPY_FUNS(DurEvent, Event);
  TA_BASEFUNS(DurEvent);
};  

//////////////////////////////////////////
// 	Time-Based Learning		//
//////////////////////////////////////////

class LeabraTimeUnit;
class LeabraTimeUnitSpec;

class LeabraTimeConSpec : public LeabraConSpec {
  // computes weight change based on recv current and send previous acts
public:
  float		k_prv;		// how much to learn from the previous senders
  float		k_cur;		// how much to learn from the current senders

  float		C_Compute_Hebb(LeabraCon* cn, LeabraCon_Group*,
			       float ru_act, float su_act, float max_cor) {
    return ru_act * (su_act * (max_cor - cn->wt_lin) -
		     (1.0f - su_act) * cn->wt_lin);
  }
    
  inline void 	C_Compute_dWt(LeabraCon* cn, float heb, float err, float k_mult) {
    float dwt = lmix.err * err + lmix.hebb * heb;
    cn->dwt += k_mult * dwt;
  }

  inline void 	Compute_dWt(Con_Group* cg, Unit* ru);

  void	UpdateAfterEdit();
  void 	Initialize();
  void	Destroy()		{ };
  void	InitLinks();
  SIMPLE_COPY(LeabraTimeConSpec);
  COPY_FUNS(LeabraTimeConSpec, LeabraConSpec);
  TA_BASEFUNS(LeabraTimeConSpec);
};

class LeabraTimeCon_Group : public LeabraCon_Group {
  // one step of history learning
public:
  float		p_savg;		// #NO_SAVE previous sending average activation
  float		p_max_cor;	// #NO_SAVE previous savg correction factor for psr_max_cor

  void		EncodeState(LeabraUnit*)  { p_savg = savg; p_max_cor = max_cor; }

  void 	Initialize();
  void	Destroy()		{ };
  void	Copy_(const LeabraTimeCon_Group& cp);
  COPY_FUNS(LeabraTimeCon_Group, LeabraCon_Group);
  TA_BASEFUNS(LeabraTimeCon_Group);
};

class LeabraTimeUnitSpec : public LeabraUnitSpec {
  // adapts weights based on one step of activation history 
public:
  void		InitState(BioBelUnit* u, BioBelLayer* lay);
  void		InitState(Unit* u)	{ LeabraUnitSpec::InitState(u); }
  void		Compute_dWt(Unit*) { };
  void		Compute_dWt(LeabraUnit* u, LeabraLayer* lay);

  void		EncodeState(LeabraUnit* u, LeabraLayer* lay);

  void	Initialize();
  void	Destroy()		{ };
  SIMPLE_COPY(LeabraTimeUnitSpec);
  COPY_FUNS(LeabraTimeUnitSpec, LeabraUnitSpec);
  TA_BASEFUNS(LeabraTimeUnitSpec);
};

class LeabraTimeUnit : public LeabraUnit {
  // LEABRA unit with an single step activation history
public:
  float 	p_act_m;	// previous minus phase activation 
  float		p_act_p;	// previous plus phase activation

  void	Initialize();
  void	Destroy()	{ };
  SIMPLE_COPY(LeabraTimeUnit);
  COPY_FUNS(LeabraTimeUnit, LeabraUnit);
  TA_BASEFUNS(LeabraTimeUnit);
};

inline void LeabraTimeConSpec::Compute_dWt(Con_Group* cg, Unit* ru) {
  LeabraTimeUnit* lru = (LeabraTimeUnit*)ru;
  LeabraTimeCon_Group* lcg = (LeabraTimeCon_Group*) cg;
  // this pass is for the sender_(t-1), recv_(t) weight change
  if((lru->p_act_p >= 0.0f) && (lcg->p_savg >= savg_cor.thresh) && (k_prv != 0.0f)) {
    for(int i=0; i<cg->size; i++) {
      LeabraTimeUnit* su = (LeabraTimeUnit*)cg->Un(i);
      LeabraCon* cn = (LeabraCon*)cg->Cn(i);
      C_Compute_dWt(cn, 
		    C_Compute_Hebb(cn, lcg, lru->act_p, su->p_act_p, lcg->p_max_cor),
		    C_Compute_Err(cn, lru->act_p, lru->act_m, su->p_act_p, su->p_act_m),
		    k_prv);
    }
  }
  // this is for the sender_(t), recv_(t) weight change
  Compute_SAvgCor(lcg, lru);
  float use_k_cur = k_cur;
  if(lru->p_act_p < 0.0f)	use_k_cur = 1.0f; // use full current if no encoded
  if((lcg->savg >= savg_cor.thresh) && (k_cur != 0.0f)) {
    for(int i=0; i<cg->size; i++) {
      LeabraTimeUnit* su = (LeabraTimeUnit*)cg->Un(i);
      LeabraCon* cn = (LeabraCon*)cg->Cn(i);
      C_Compute_dWt(cn, 
		    C_Compute_Hebb(cn, lcg, lru->act_p, su->act_p, lcg->max_cor),
		    C_Compute_Err(cn, lru->act_p, lru->act_m, su->act_p, su->act_m),
		    use_k_cur);
    }
  }
}


//////////////////////////////////////////
// 	Misc Special Objects		//
//////////////////////////////////////////

#endif // leabra_h

